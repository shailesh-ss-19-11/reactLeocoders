import React from 'react'

export default function UserDetails() {
  return (
    <div>
      userDetails
    </div>
  )
}
