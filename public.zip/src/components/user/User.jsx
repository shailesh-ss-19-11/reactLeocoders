const User = ()=>{
    
    return(
        <>
            <h1>hello</h1>
        </>
    )
}

export default User;